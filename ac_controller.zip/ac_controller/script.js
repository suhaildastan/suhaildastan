class ACController {
    constructor() {
        this.state = {
            power: false,
            temp: 24,
            modeIndex: 0, // 0: Cool, 1: Heat, 2: Dry, 3: Fan
            fanIndex: 0   // 0: Auto, 1: Low, 2: Med, 3: High
        };

        this.modes = [
            { name: 'COOL', icon: 'ac_unit', color: 'var(--primary-color)' },
            { name: 'HEAT', icon: 'local_fire_department', color: 'var(--hot-color)' },
            { name: 'DRY', icon: 'water_drop', color: 'var(--dry-color)' },
            { name: 'FAN', icon: 'cyclone', color: 'var(--fan-color)' }
        ];

        this.fanSpeeds = ['AUTO', 'LOW', 'MED', 'HIGH'];

        this.minTemp = 16;
        this.maxTemp = 30;

        // Elements
        this.panel = document.getElementById('acPanel');
        this.tempDisplay = document.getElementById('tempValue');
        this.modeIcon = document.getElementById('modeIcon');
        this.modeText = document.getElementById('modeText');
        this.fanIcon = document.getElementById('fanIcon');
        this.fanText = document.getElementById('fanText');

        // Bind buttons
        document.getElementById('powerBtn').addEventListener('click', () => this.togglePower());
        document.getElementById('tempUpBtn').addEventListener('click', () => this.changeTemp(1));
        document.getElementById('tempDownBtn').addEventListener('click', () => this.changeTemp(-1));
        document.getElementById('modeBtn').addEventListener('click', () => this.cycleMode());
        document.getElementById('fanBtn').addEventListener('click', () => this.cycleFan());

        this.init();
    }

    init() {
        // Initial render logic
        this.updateUI();
    }

    togglePower() {
        this.state.power = !this.state.power;
        this.updateUI();
    }

    changeTemp(delta) {
        if (!this.state.power) return;

        const newTemp = this.state.temp + delta;
        if (newTemp >= this.minTemp && newTemp <= this.maxTemp) {
            this.state.temp = newTemp;
            this.updateUI();
        }
    }

    cycleMode() {
        if (!this.state.power) return;
        this.state.modeIndex = (this.state.modeIndex + 1) % this.modes.length;
        this.updateUI();
    }

    cycleFan() {
        if (!this.state.power) return;
        this.state.fanIndex = (this.state.fanIndex + 1) % this.fanSpeeds.length;
        this.updateUI();
    }

    updateUI() {
        // Power State
        if (this.state.power) {
            this.panel.classList.remove('off');
        } else {
            this.panel.classList.add('off');
        }

        // Temp Display
        this.tempDisplay.textContent = this.state.temp;

        // Mode Display
        const currentMode = this.modes[this.state.modeIndex];
        this.modeText.textContent = currentMode.name;
        this.modeIcon.textContent = currentMode.icon;

        // Color update based on mode
        this.tempDisplay.style.color = currentMode.color;
        this.modeIcon.style.color = currentMode.color;

        // Fan Display
        this.fanText.textContent = this.fanSpeeds[this.state.fanIndex];

        // Fan Icon Animation speed based on setting
        this.fanIcon.style.animation = this.state.power ? `spin ${this.getFanSpeedDuration()}s linear infinite` : 'none';
    }

    getFanSpeedDuration() {
        switch (this.state.fanIndex) {
            case 1: return 2; // Low
            case 2: return 1; // Med
            case 3: return 0.5; // High
            default: return 1.5; // Auto
        }
    }
}

// Add simple spin animation dynamically
const styleSheet = document.createElement("style");
styleSheet.innerText = `
@keyframes spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}
`;
document.head.appendChild(styleSheet);

// Initialize
const ac = new ACController();

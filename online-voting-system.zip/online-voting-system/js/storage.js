/**
 * Mock Backend & Storage Layer
 * Simulates a database using LocalStorage
 */

const STORAGE_KEYS = {
    USERS: 'ovs_users',
    CANDIDATES: 'ovs_candidates',
    VOTES: 'ovs_votes',
    SESSION: 'ovs_session',
    ELECTION_STATE: 'ovs_election_active'
};

// Seed initial data if empty
function initializeStorage() {
    if (!localStorage.getItem(STORAGE_KEYS.USERS)) {
        // Create a default admin
        const admin = {
            id: 'admin',
            username: 'admin',
            password: 'password123',
            role: 'admin',
            hasVoted: false
        };
        localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify([admin]));
    }

    if (!localStorage.getItem(STORAGE_KEYS.CANDIDATES)) {
        localStorage.setItem(STORAGE_KEYS.CANDIDATES, JSON.stringify([]));
    }

    if (!localStorage.getItem(STORAGE_KEYS.VOTES)) {
        localStorage.setItem(STORAGE_KEYS.VOTES, JSON.stringify({}));
    }
}

// Auth Methods
function login(username, password) {
    const users = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
    const user = users.find(u => u.username === username && u.password === password);

    if (user) {
        localStorage.setItem(STORAGE_KEYS.SESSION, JSON.stringify(user));
        return { success: true, user };
    }
    return { success: false, message: 'Invalid credentials' };
}

function register(username, password) {
    const users = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
    if (users.find(u => u.username === username)) {
        return { success: false, message: 'Username already exists' };
    }

    const newUser = {
        id: 'user_' + Date.now(),
        username,
        password,
        role: 'voter',
        hasVoted: false
    };

    users.push(newUser);
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));

    // Auto login after register
    localStorage.setItem(STORAGE_KEYS.SESSION, JSON.stringify(newUser));
    return { success: true, user: newUser };
}

function logout() {
    localStorage.removeItem(STORAGE_KEYS.SESSION);
    window.location.href = 'index.html';
}

function getCurrentUser() {
    return JSON.parse(localStorage.getItem(STORAGE_KEYS.SESSION));
}

function requireAuth(role = null) {
    const user = getCurrentUser();
    if (!user) {
        window.location.href = 'index.html';
        return null;
    }
    if (role && user.role !== role) {
        alert('Access denied');
        window.location.href = user.role === 'admin' ? 'admin.html' : 'vote.html';
        return null;
    }
    return user;
}

// Voting Methods
function getCandidates() {
    return JSON.parse(localStorage.getItem(STORAGE_KEYS.CANDIDATES) || '[]');
}

function addCandidate(name, party) {
    const candidates = getCandidates();
    const newCandidate = {
        id: 'cand_' + Date.now(),
        name,
        party,
        color: getRandomColor()
    };
    candidates.push(newCandidate);
    localStorage.setItem(STORAGE_KEYS.CANDIDATES, JSON.stringify(candidates));

    // Initialize vote count for new candidate
    const votes = getVotes();
    votes[newCandidate.id] = 0;
    saveVotes(votes);

    return newCandidate;
}

function resetElection() {
    // Keep users but reset their voted status
    const users = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
    users.forEach(u => u.hasVoted = false);
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));

    // Clear candidates and votes
    localStorage.setItem(STORAGE_KEYS.CANDIDATES, JSON.stringify([]));
    localStorage.setItem(STORAGE_KEYS.VOTES, JSON.stringify({}));

    // Update current session if logged in
    const session = getCurrentUser();
    if (session) {
        session.hasVoted = false;
        localStorage.setItem(STORAGE_KEYS.SESSION, JSON.stringify(session));
    }
}

function castVote(candidateId) {
    const user = getCurrentUser();
    if (!user) return { success: false, message: 'Not logged in' };

    // Refresh user data from store to check absolute latest status
    const allUsers = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
    const storedUser = allUsers.find(u => u.id === user.id);

    if (storedUser.hasVoted) {
        return { success: false, message: 'You have already voted!' };
    }

    const votes = getVotes();
    if (votes[candidateId] === undefined) votes[candidateId] = 0;
    votes[candidateId]++;
    saveVotes(votes);

    // Mark user as voted
    storedUser.hasVoted = true;
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(allUsers));

    // Update session
    user.hasVoted = true;
    localStorage.setItem(STORAGE_KEYS.SESSION, JSON.stringify(user));

    return { success: true };
}

function getVotes() {
    return JSON.parse(localStorage.getItem(STORAGE_KEYS.VOTES) || '{}');
}

function saveVotes(votes) {
    localStorage.setItem(STORAGE_KEYS.VOTES, JSON.stringify(votes));
}

// Utilities
function getRandomColor() {
    const letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}

initializeStorage();

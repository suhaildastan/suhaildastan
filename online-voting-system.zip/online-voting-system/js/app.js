/**
 * Shared Application Logic
 */

// Simple notification toaster
function showNotification(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `glass-card`;
    toast.style.position = 'fixed';
    toast.style.bottom = '20px';
    toast.style.right = '20px';
    toast.style.padding = '1rem 2rem';
    toast.style.zIndex = '1000';
    toast.style.borderLeft = `5px solid ${type === 'success' ? 'var(--success)' : 'var(--danger)'}`;
    toast.style.animation = 'fadeIn 0.3s ease-out';

    toast.innerHTML = `<span style="font-weight:600">${message}</span>`;

    document.body.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(10px)';
        toast.style.transition = 'all 0.3s';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Redirect helpers based on role
function checkRedirect() {
    const user = JSON.parse(localStorage.getItem('ovs_session'));
    const path = window.location.pathname;

    if (user) {
        if (path.includes('index.html') || path.endsWith('/')) {
            if (user.role === 'admin') window.location.href = 'admin.html';
            else window.location.href = 'vote.html';
        }
    }
}

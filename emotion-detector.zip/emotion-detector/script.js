const video = document.getElementById('video');
const statusText = document.getElementById('status-text');

// Emotion bar elements
const emotionBars = {
    neutral: document.getElementById('bar-neutral'),
    happy: document.getElementById('bar-happy'),
    sad: document.getElementById('bar-sad'),
    angry: document.getElementById('bar-angry'),
    surprised: document.getElementById('bar-surprised'),
    disgusted: document.getElementById('bar-disgusted'),
    fearful: document.getElementById('bar-fearful')
};

// Start Video Stream
function startVideo() {
    navigator.mediaDevices.getUserMedia({ video: {} })
        .then(stream => {
            video.srcObject = stream;
        })
        .catch(err => {
            console.error(err);
            statusText.innerText = "Error: Camera access denied";
        });
}

// Load Models
Promise.all([
    faceapi.nets.tinyFaceDetector.loadFromUri('https://justadudewhohacks.github.io/face-api.js/models'),
    faceapi.nets.faceLandmark68Net.loadFromUri('https://justadudewhohacks.github.io/face-api.js/models'),
    faceapi.nets.faceRecognitionNet.loadFromUri('https://justadudewhohacks.github.io/face-api.js/models'),
    faceapi.nets.faceExpressionNet.loadFromUri('https://justadudewhohacks.github.io/face-api.js/models')
]).then(() => {
    statusText.innerText = "Models Loaded. Starting Camera...";
    startVideo();
}).catch(err => {
    console.error(err);
    statusText.innerText = "Error Loading Models. Please run on a local server (CORS restrictions).";
    statusText.style.color = "#ef4444";
});

video.addEventListener('play', () => {
    statusText.innerText = "Detecting Emotions...";

    // Create canvas overlay
    const canvas = faceapi.createCanvasFromMedia(video);
    document.querySelector('.video-container').append(canvas);

    const displaySize = { width: video.width, height: video.height };
    faceapi.matchDimensions(canvas, displaySize);

    setInterval(async () => {
        const detections = await faceapi.detectAllFaces(video, new faceapi.TinyFaceDetectorOptions())
            .withFaceLandmarks()
            .withFaceExpressions();

        const resizedDetections = faceapi.resizeResults(detections, displaySize);

        // Clear canvas
        canvas.getContext('2d').clearRect(0, 0, canvas.width, canvas.height);

        // Draw detections (optional, can look messy on a nice UI, maybe just the box)
        faceapi.draw.drawDetections(canvas, resizedDetections);
        // faceapi.draw.drawFaceExpressions(canvas, resizedDetections); // Using custom UI instead

        if (detections.length > 0) {
            // Get expressions from the first face detected
            const expressions = detections[0].expressions;
            updateDashboard(expressions);
        } else {
            // Reset bars if no face
            Object.values(emotionBars).forEach(bar => {
                bar.style.width = '0%';
            });
        }
    }, 100);
});

function updateDashboard(expressions) {
    // expressions object: { neutral: 0.9, happy: 0.1, ... }

    // Find dominant emotion
    const dominant = Object.keys(expressions).reduce((a, b) => expressions[a] > expressions[b] ? a : b);

    statusText.innerText = `Dominant Emotion: ${dominant.charAt(0).toUpperCase() + dominant.slice(1)}`;
    statusText.style.color = getEmotionColor(dominant);

    // Update bars
    for (const [emotion, value] of Object.entries(expressions)) {
        if (emotionBars[emotion]) {
            const percentage = Math.min(Math.max(value * 100, 5), 100); // Min 5% so it's visible
            emotionBars[emotion].style.width = `${percentage}%`;
        }
    }
}

function getEmotionColor(emotion) {
    const colors = {
        neutral: '#94a3b8',
        happy: '#22c55e',
        sad: '#64748b',
        angry: '#ef4444',
        surprised: '#eab308',
        disgusted: '#10b981',
        fearful: '#a855f7'
    };
    return colors[emotion] || '#fff';
}
